const form = document.getElementById('bookingForm');
const dateInput = document.getElementById('date');
const timeInput = document.getElementById('time');
const result = document.getElementById('result');
const now = new Date();
const today = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0,10);
dateInput.min = today;

async function loadSlots() {
  timeInput.disabled = true;
  timeInput.innerHTML = '<option value="">Загрузка свободного времени…</option>';
  if (!dateInput.value) { timeInput.innerHTML = '<option value="">Сначала выберите дату</option>'; return; }
  try {
    const response = await fetch(`/api/slots?date=${encodeURIComponent(dateInput.value)}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Не удалось загрузить время.');
    timeInput.innerHTML = '';
    if (!data.times.length) { timeInput.innerHTML = '<option value="">Свободного времени нет</option>'; return; }
    timeInput.add(new Option('Выберите время', ''));
    data.times.forEach(t => timeInput.add(new Option(t, t)));
    timeInput.disabled = false;
  } catch (e) {
    timeInput.innerHTML = '<option value="">Не удалось загрузить время</option>';
    result.textContent = e.message;
  }
}
dateInput.addEventListener('change', loadSlots);
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  result.textContent = 'Отправляем заявку…';
  const payload = {
    name: document.getElementById('name').value,
    phone: document.getElementById('phone').value,
    service: document.getElementById('service').value,
    date: dateInput.value,
    time: timeInput.value,
    details: document.getElementById('details').value,
    consent: document.getElementById('consent').checked
  };
  try {
    const response = await fetch('/api/bookings', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Не удалось отправить заявку.');
    result.textContent = data.message;
    form.reset(); dateInput.min = today; timeInput.disabled = true;
    timeInput.innerHTML = '<option value="">Сначала выберите дату</option>';
  } catch (e) { result.textContent = e.message; if (responseIsConflict(e)) loadSlots(); }
});
function responseIsConflict(error) { return /уже занято/i.test(error.message); }
